#include <Arduino.h>
int n=13;
void setup() {
  pinMode(n,OUTPUT);
  // put your setup code here, to run once:
}

void loop() {
  digitalWrite(n,HIGH);
  delay(500);
  digitalWrite(n,LOW);
  delay(500);
  // put your main code here, to run repeatedly:
}
